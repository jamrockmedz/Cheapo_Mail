Cheapo_Mail
===========

INFO 2110 Project 4
